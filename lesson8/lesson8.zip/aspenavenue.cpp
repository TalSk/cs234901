#include <algorithm>
#include <bitset>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <vector>

using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<vector<int>> vvi;
typedef pair<int, int> ii;
typedef vector<pair<int, int>> vii;
typedef vector<vector<pair<int, int>>> vvii;
typedef long long ll;

long double dist(pair<long double, long double> first,
                 pair<long double, long double> second) {
  auto dist =
      sqrt((first.first - second.first) * (first.first - second.first) +
           (first.second - second.second) * (first.second - second.second));
  return dist;
}

bool sortByy(pair<long double, long double> a,
             pair<long double, long double> b) {
  return a.second < b.second;
}

int main() {
  ll N;
  while (cin >> N) {
    long double L, W;
    cin >> L >> W;
    vector<pair<long double, long double>> trees(N);
    long double y;
    for (int i = 0; i < N; ++i) {
      cin >> y;
      trees[i] = {0, y};
    }
    sort(trees.begin(), trees.end(), sortByy);
    auto num_trees_per_side = N / 2;
    vector<pair<long double, long double>> left_possible_points(
        num_trees_per_side);
    vector<pair<long double, long double>> right_possible_points(
        num_trees_per_side);
    for (int j = 0; j < num_trees_per_side; ++j) {
      left_possible_points[j] = {0, j * L / (num_trees_per_side - 1)};
      right_possible_points[j] = {W, j * L / (num_trees_per_side - 1)};
    }

    vector<vector<long double>> mem(
        num_trees_per_side + 1, vector<long double>(num_trees_per_side + 1));
    mem[0][0] = 0;
    for (int i = 1; i < num_trees_per_side + 1; ++i) {
      mem[i][0] =
          mem[i - 1][0] + dist(trees[i - 1], left_possible_points[i - 1]);
    }
    for (int i = 1; i < num_trees_per_side + 1; ++i) {
      mem[0][i] =
          mem[0][i - 1] + dist(trees[i - 1], right_possible_points[i - 1]);
    }
    for (int i = 1; i < num_trees_per_side + 1; ++i) {
      for (int j = 1; j < num_trees_per_side + 1; ++j) {
        mem[i][j] = min(
            mem[i - 1][j] + dist(trees[i + j - 1], left_possible_points[i - 1]),
            mem[i][j - 1] +
                dist(trees[i + j - 1], right_possible_points[j - 1]));
      }
    }

    printf("%.10Lf\n", mem[num_trees_per_side][num_trees_per_side]);
  }
  return 0;
}